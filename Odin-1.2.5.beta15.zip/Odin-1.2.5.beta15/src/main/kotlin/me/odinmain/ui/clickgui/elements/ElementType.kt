package me.odinmain.ui.clickgui.elements

enum class ElementType {
    CHECK_BOX, KEY_BIND, SELECTOR, SLIDER, TEXT_FIELD, COLOR, ACTION, DUAL, DROPDOWN
}