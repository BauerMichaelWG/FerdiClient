package me.odinmain.features

enum class Category {
    DUNGEON, FLOOR7, RENDER, SKYBLOCK, NETHER
}