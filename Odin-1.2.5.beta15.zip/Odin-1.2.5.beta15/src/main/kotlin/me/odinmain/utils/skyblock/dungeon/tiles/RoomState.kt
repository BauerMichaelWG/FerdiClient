package me.odinmain.utils.skyblock.dungeon.tiles

enum class RoomState {
    CLEARED, DISCOVERED, FAILED, GREEN, UNDISCOVERED
}