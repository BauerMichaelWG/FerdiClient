package me.odinmain.utils.skyblock.dungeon.tiles

enum class RoomType {
    BLOOD, CHAMPION, ENTRANCE, FAIRY, NORMAL, PUZZLE, RARE, TRAP
}