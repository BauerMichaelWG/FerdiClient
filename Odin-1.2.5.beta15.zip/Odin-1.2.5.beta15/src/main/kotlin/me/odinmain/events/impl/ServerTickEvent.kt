package me.odinmain.events.impl

import net.minecraftforge.fml.common.eventhandler.Event

class ServerTickEvent : Event()