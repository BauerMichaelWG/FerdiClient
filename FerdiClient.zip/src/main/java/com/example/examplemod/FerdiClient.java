package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

@Mod(modid = FerdiClient.MODID, name = FerdiClient.NAME, version = FerdiClient.VERSION)
public class FerdiClient {
    public static final String MODID = "ferdiclient";
    public static final String NAME = "Ferdi Client";
    public static final String VERSION = "1.0";

    private static final String LOG_DIRECTORY = "C:\\Users\\rbran\\Desktop\\Ferdi Client\\Player-Tracking";
    private boolean isTrackingEnabled = false; // Tracking-Status

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);

        // Sicherstellen, dass das Log-Verzeichnis existiert
        File logDir = new File(LOG_DIRECTORY);
        if (!logDir.exists()) {
            logDir.mkdirs();
        }
    }

    @Mod.EventHandler
    public void onServerStart(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandBase() {
            @Override
            public String getCommandName() {
                return "autohighlight";
            }

            @Override
            public String getCommandUsage(ICommandSender sender) {
                return "/autohighlight <enable|disable>";
            }

            @Override
            public void processCommand(ICommandSender sender, String[] args) {
                if (args.length == 1) {
                    if (args[0].equalsIgnoreCase("enable")) {
                        isTrackingEnabled = true;
                        sendChatMessage(sender, "AutoHighlight enabled");
                    } else if (args[0].equalsIgnoreCase("disable")) {
                        isTrackingEnabled = false;
                        sendChatMessage(sender, "AutoHighlight disabled");
                    } else {
                        sender.addChatMessage(new ChatComponentText("Invalid usage. Use /autohighlight <enable|disable>"));
                    }
                } else {
                    sender.addChatMessage(new ChatComponentText("Invalid usage. Use /autohighlight <enable|disable>"));
                }
            }

            @Override
            public int getRequiredPermissionLevel() {
                return 0; // Erlaubt allen Spielern die Nutzung dieses Befehls
            }

            private void sendChatMessage(ICommandSender sender, String message) {
                sender.addChatMessage(new ChatComponentText("[FerdiClient] " + message));
            }
        });

        event.registerServerCommand(new CommandBase() {
            @Override
            public String getCommandName() {
                return "fc";
            }

            @Override
            public String getCommandUsage(ICommandSender sender) {
                return "/fc";
            }

            @Override
            public void processCommand(ICommandSender sender, String[] args) {
                if (sender instanceof EntityPlayer) {
                    EntityPlayer player = (EntityPlayer) sender;
                    Minecraft.getMinecraft().displayGuiScreen(new FerdiClientGui(player));
                }
            }
        });
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (!isTrackingEnabled || event.player.worldObj.isRemote) return;

        double currentX = event.player.posX;
        double currentY = event.player.posY;
        double currentZ = event.player.posZ;

        logToFile("player_tracking.log", "Position: X=" + currentX + " Y=" + currentY + " Z=" + currentZ);
    }

    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!isTrackingEnabled) return;

        String blockName = event.state.getBlock().getLocalizedName();
        logToFile("block_break.log", "Block broken: " + blockName + " at " + event.pos);
    }

    @SubscribeEvent
    public void onItemPickup(EntityItemPickupEvent event) {
        if (!isTrackingEnabled) return;

        String itemName = event.item.getEntityItem().getDisplayName();
        logToFile("item_pickups.log", "Item picked up: " + itemName);
    }

    private void logToFile(String fileName, String data) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(new File(LOG_DIRECTORY, fileName), true);
            writer.write(data + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

class FerdiClientGui extends GuiScreen {
    private final EntityPlayer player;

    public FerdiClientGui(EntityPlayer player) {
        this.player = player;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(this.fontRendererObj, "Ferdi Client", this.width / 2, 20, 0xFFFFFF);
        drawCenteredString(this.fontRendererObj, "Features:", this.width / 2, 40, 0xFFFFFF);

        drawString(this.fontRendererObj, "- AutoHighlight", this.width / 2 - 100, 60, 0x00FF00);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
